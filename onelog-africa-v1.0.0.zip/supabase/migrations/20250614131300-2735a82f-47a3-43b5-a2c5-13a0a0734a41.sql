
ALTER TABLE public.missions ADD COLUMN description TEXT;
